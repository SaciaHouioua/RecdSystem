#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 28 10:49:44 2021

@author: sacia
"""




import numpy as np

from lightfm import LightFM

from scipy.sparse import csr_matrix
import random  

#data = pd.read_csv('data.csv')

def ArtistRandom (liste, nbr):
    # Obtenir échantillon de 6 éléments  
    selection = random.sample(liste, nbr) 
    return selection

def listartist (ap) :
    # Group artist by name
    artist_rank = ap.groupby(['name']) \
        .agg({'userID' : 'count', 'playCount' : 'sum'}) \
        .rename(columns={"userID" : 'totalUsers', "playCount" : "totalPlays"}) \
        .sort_values(['totalPlays'], ascending=False)

    artist_rank['avgPlays'] = artist_rank['totalPlays'] / artist_rank['totalUsers']

       
    # Merge into ap matrix
    ap = ap.join(artist_rank, on="name", how="inner") \
    .sort_values(['playCount'], ascending=False)

    # Preprocessing
    pc = ap.playCount
    play_count_scaled = (pc - pc.min()) / (pc.max() - pc.min())
    ap = ap.assign(playCountScaled=play_count_scaled)
    #print(ap)

    # Build a user-artist rating matrix 
    ratings_df = ap.pivot(index='userID', columns='artistID', values='playCountScaled')
    ratings = ratings_df.fillna(0).values
    
    artist_names = ap.sort_values("artistID")["name"].unique()
    
    return ratings, artist_names

def buildSM(ratings) : 
    # Build a sparse matrix
    X = csr_matrix(ratings)
    return X

def get_recommendation(model, data, user_id ,artist_names, n):
    n_users, n_items = data.shape
    scores = model.predict(user_id, np.arange(n_items))
    top_items = artist_names[np.argsort(-scores)]
    
    return  top_items [:n]

# vectoriser la liste listeName introduite par l'utilisateur

def vectoriserlistArtists(listIndex ,  n) :
    # reprsente la taille de notre vecteur n = 17631
    Z = np.zeros(shape = (1,n))
    for index in listIndex:
        # la valeur 1 sera remplacée par la moyenne playCountScaled de l'artiste en question
        Z[0][index] = 1
    
    return Z

# trouver la liste des index d'artistes introduits par l'utilisateur

def listIndexArtist(listName, artist_name):
    
    listIndex = []
    for name in listName :
        listIndex.append(list(artist_name).index(name))
    return listIndex

# vectoriser la liste listeName introduite par l'utilisateur

def modeloptimal():
    # définition du model  avec la combinaison de paramètres qui permet d'optimiser le modèle : 0.81 est la suivante 
    modeloptimal = LightFM(learning_schedule = 'adadelta',loss='warp', learning_rate=0.08)
    return modeloptimal


