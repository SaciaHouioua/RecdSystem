#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 27 16:26:21 2021

@author: sacia
"""

# port utilisé est le 5004
"""
from flask import Flask

app = Flask(__name__)

@app.route('/')
def index():
    return "Welcome Sytème de recommandation !"

if __name__ == '__main__':
    app.run(debug=True)
    
 """   
    
from flask import Flask, redirect, url_for, render_template, request



import pandas as pd
#from lightfm import LightFM
from scipy.sparse import vstack


import fonction


data = pd.read_csv('data.csv')

# Build a user-artist rating matrix 
ratings, artist_names = fonction.listartist (data)

# Build a sparse matrix
X = fonction.buildSM(ratings)


#listArtist = data['name'].unique()
#ListA = listArtist[:100]

# selection de 50 artiste d'une manière aléatoire
#ListA = fonction.ArtistRandom(list(artist_names), 100)



# definition du modèle optimal
model = fonction.modeloptimal ()  


# def create_app():
app = Flask(__name__,template_folder = "templates")



@app.route("/")         
def listArtist():
    #ListA
    # selection de 100 artiste d'une manière aléatoire
    ListA = fonction.ArtistRandom(list(artist_names), 1000)
    
    return render_template ("listArtist.html", artist=ListA)

    
@app.route("/homepage", methods=['GET',"POST"])
def homepage():
    
    name=request.form.getlist("listart")
    
    #  recupérer les index de la liste des artistes introduite par l'user
    listIndex = fonction.listIndexArtist(name,artist_names) 
    #vectoriser la liste des artistes données par l'utilisateur à partir de la liste d'index
    # newVect a la laille n de la matrice sparce X.shape[1] : nbr d'artistes
    newVect = fonction.vectoriserlistArtists(listIndex , X.shape[1])  

    # add the new row to ths space matrix
    NewX = vstack([X,newVect])

    model.fit(NewX, epochs=10, num_threads=2)

    userId = NewX.shape[0]
    recommandation = fonction.get_recommendation(model, NewX, userId-1 ,artist_names,10)

    
    return render_template('homepage.html', artist=recommandation )
 
    
 #######
    
@app.route('/cool_form', methods=['GET', 'POST'])
def cool_form():
    if request.method == 'POST':
        # do stuff when the form is submitted

        # redirect to end the POST handling
        # the redirect can be to the same route or somewhere else
        return redirect(url_for('index'))

    # show the form, it wasn't submitted
    return render_template('cool_form.html')
    
 
    
 ########
    
 
    


if __name__ == '__main__':
    app.run(debug=True)




    